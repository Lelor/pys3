from setuptools import setup

setup(
    name='pys3'
)
